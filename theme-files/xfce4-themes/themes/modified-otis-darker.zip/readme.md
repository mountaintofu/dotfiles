theme based on:
-Square dots white (https://github.com/Acvale/xfwm4-gaps-themes/tree/main/Square%20Dots%20White)
-otis standard button (https://github.com/EliverLara/otis)